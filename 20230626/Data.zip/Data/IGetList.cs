﻿namespace Data
{
    public interface IGetList<T>
    {
        IEnumerable<T> GetList();
    }
}
